# Wildlife

<img alt="Wildlife page template" src="https://github.com/HangeZoe/wildlife/blob/main/wildlife.jpg"/>

A very simple web page ideal for beginner front-end developers. This web page is an assignment on a free programming course from [RS School](https://rs.school/).

[Link to Figma](https://www.figma.com/file/dJoqHi1YHTLR06PPEeCc7t/Wildlife)

-----

Velmi jednoduchá webová stránka, ideální pro začínající vývojáře frontendů. Vytvoření této stránky bylo jedním z úkolů bezplatných kurzů [RS School](https://rs.school/).

[Odkaz na Figmu](https://www.figma.com/file/dJoqHi1YHTLR06PPEeCc7t/Wildlife)

------

Очень простая веб-страница, идеальна для начинающих фронтенд разработчиков. Верстка этой страницы была одним из заданий на бесплатных курсах [RS School](https://rs.school/).

[Ссылка на макет Figma](https://www.figma.com/file/dJoqHi1YHTLR06PPEeCc7t/Wildlife)
